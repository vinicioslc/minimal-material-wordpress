 <!-- RODAPÉ  -->
        <footer>
            <div class="footer">
                <h1 class="text-center">Me envie um Olá :)</h1>
                <div class="links text-center">
                    <a href="https://www.facebook.com/vinicioslc" title="Abrir Facebook" target="_blank" class="margin-right-3vw">
                        <div class="icon animation-hover-fade">
                            <div class="facebook-icon"></div>
                        </div>
                    </a>
                    <a href="https://br.linkedin.com/in/vinicioslc" title="Abrir Linkedin" target="_blank" class="margin-right-3vw">
                        <div class="icon animation-hover-fade">
                            <div class="linkedin-icon"></div>
                        </div>
                    </a>
                    <a class="text-center text-center-midle animation-hover-fade" title="Enviar e-mail" href="mailto:vinicioslc@outlook.com">vinicioslc@outlook.com</a>
                </div>
            </div>
            <dynamic-stylesheet></dynamic-stylesheet>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <?php 
            wp_get_footer( );
            ?>
        </footer>
    </main>
</body>


</html>