### Minimal Material
A theme based on Material design And Fluent Design for Wordpress that i have maded for my personal website.

### Screenshot :
![Posts PrintScreen](https://github.com/vinicioslc/minimal-material-wordpress/blob/master/screenshot.png)
